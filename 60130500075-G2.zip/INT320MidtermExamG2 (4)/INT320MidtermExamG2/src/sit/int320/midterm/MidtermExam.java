/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int320.midterm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class MidtermExam {

    public static String getTopMostNumber(int[] numbers) {
        Map<Integer, KeyAndPosition> freq = new HashMap();
        int key;
        for (int i = 0; i < numbers.length; i++) {
            key = numbers[i];
            if (freq.get(key) == null) {
                freq.put(key, new KeyAndPosition(key, i));
            } else {
                freq.get(key).addPosition(i);
            }
        }
        List<KeyAndPosition> list = new ArrayList(freq.values());
        Collections.sort(list);
// test
//        for (KeyAndPosition keyAndPosition : list) {
//            System.out.println(keyAndPosition.key + " ( " + keyAndPosition.positions.size() + " ) " + keyAndPosition.positions);
//        }
        KeyAndPosition result = list.get(0);
        return result.key + " (" + result.positions.size() + ") : " + result.positions; //format มีผล
    }

    public static String infixToPostfix(String exp) {
        StringBuilder result = new StringBuilder(128);
        StringTokenizer stk = new StringTokenizer(exp, " ()+-*/%", true);
        LinkedList<String> stack = new LinkedList();
        String token;
        while (stk.hasMoreElements()) {
            token = stk.nextToken();
            if (token.equals(" ")) {
                continue; //doing notings white space 
            } else if (!isOperator(token)) {
//               System.out.println(token+" is operator level: "+precedencaLevel(token));
                result.append(" ");
                result.append(token);
            } else if (token.equals("(")) {
                stack.push(token);
            } else if (token.equals(")")) {
                while (!stack.isEmpty() && !"(".equals(stack.peek())) {
                    result.append(" ");
                    result.append(stack.pop());
                }
                if (!stack.isEmpty()) {
                    stack.pop();
                }
            } else {
                while (!stack.isEmpty() && precedencaLevel(token) <= precedencaLevel(stack.peek())) {
                    result.append(" ");
                    result.append(stack.pop());
                }
                stack.push(token);
            }
        }
        while(!stack.isEmpty()){
            result.append(" ");
            result.append(stack.pop());
        }
        return result.toString().trim();
    }

    private static int precedencaLevel(String operator) {
        switch (operator) {
            case "(":
            case ")":
                return 0;
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
            case "%":
                return 2;
        }
        throw new RuntimeException("Invalid operator");
    }

    private static boolean isOperator(String operator) {
        switch (operator) {
            case "(":
            case ")":
            case "+":
            case "-":
            case "*":
            case "/":
            case "%":
                return true;
        }
        return false;
    }

    public static Object[] arrayUnion(Object[] obj1, Object[] obj2) {
        return arrayUnion(obj1, obj2, null);
    }

    public static Object[] arrayUnion(Object[] obj1, Object[] obj2, Comparator c) {
        Set setA;
        if (c == null) {
            setA = new TreeSet();
        } else {
            setA = new TreeSet(c);
        }
        setA.addAll(Arrays.asList(obj1));
        setA.addAll(Arrays.asList(obj2));
        return setA.toArray();

    }

    public static void main(String[] args) {
//--------------------Array union-------------------------------------------
//        String[] a = {"A", "B", "C", "D", "e", "f", "x"};
//        String[] b = {"a", "b", "C", "d", "e", "x"};
//        System.out.println(Arrays.toString(arrayUnion(a, b)));
//--------------------------------------------------------------------------
//--------------------Get Most number---------------------------------------
//        int[] x = {1, 3, 5, 6, 3, 5, 7, 3, 1, 5, 1, 7};
        //       getTopMostNumber(x);
//        System.out.println(getTopMostNumber(x));
//--------------------------------------------------------------------------
//--------------------InfixToPostfix----------------------------------------
        String exp = "A + (B - salary/2.59*x%b";
        infixToPostfix(exp);
        
    }

}

class KeyAndPosition implements Comparable<KeyAndPosition> {

    int key;
    List<Integer> positions = new ArrayList(20);

    public KeyAndPosition(int key, int position) {
        this.key = key;
        positions.add(position);
    }

    public void addPosition(int position) {
        this.positions.add(position);

    }

    @Override
    public int compareTo(KeyAndPosition o) {
        int first = o.positions.size() - this.positions.size();
        if (first != 0) {
            return first;
        } else {
            return this.key - o.key;
        }
    }
}
